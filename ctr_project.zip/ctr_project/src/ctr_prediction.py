# ad_click_project.py
# ---------------------
# Ad Spend Optimizer - Minor Project
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import pickle

from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, confusion_matrix
)

# ---------------------
# 1. LOAD DATA
# ---------------------
df = pd.read_csv("advertising_sample.csv")
print("Dataset Shape:", df.shape)
print(df.head())

# ---------------------
# 2. EXPLORATORY DATA ANALYSIS (EDA)
# ---------------------
print("\n--- EDA ---")
print(df.info())
print(df.describe())

# Correlation heatmap (numeric only)
plt.figure(figsize=(10,6))
sns.heatmap(df.corr(numeric_only=True), annot=True, cmap="coolwarm", fmt=".2f")
plt.title("Correlation Heatmap")
plt.show()

# Distribution of target variable
sns.countplot(x="Clicked", data=df, palette="Set2")
plt.title("Target Distribution (Clicked)")
plt.show()

# ---------------------
# 3. FEATURE ENGINEERING & PREPROCESSING
# ---------------------
print("\n--- FEATURE ENGINEERING ---")
target = "Clicked"

# Numeric features
num_features = df.select_dtypes(include=['number']).columns.tolist()
if target in num_features:
    num_features.remove(target)

# Categorical features
cat_features = df.select_dtypes(include=['object']).columns.tolist()

# One-hot encode categorical variables
df_enc = pd.get_dummies(df[num_features + cat_features], drop_first=True)

X = df_enc
y = df[target].astype(int)

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, stratify=y, random_state=42
)

# ---------------------
# 4. MODEL BUILDING & TRAINING
# ---------------------
print("\n--- MODEL TRAINING ---")
model = RandomForestClassifier(n_estimators=200, random_state=42, n_jobs=-1)
model.fit(X_train, y_train)

# ---------------------
# 5. MODEL EVALUATION
# ---------------------
print("\n--- MODEL EVALUATION ---")
y_pred = model.predict(X_test)
y_proba = model.predict_proba(X_test)[:,1]

print("Accuracy:", accuracy_score(y_test, y_pred))
print("Precision:", precision_score(y_test, y_pred))
print("Recall:", recall_score(y_test, y_pred))
print("F1 Score:", f1_score(y_test, y_pred))
print("ROC-AUC:", roc_auc_score(y_test, y_proba))

# Confusion Matrix
cm = confusion_matrix(y_test, y_pred)
sns.heatmap(cm, annot=True, fmt="d", cmap="Blues")
plt.title("Confusion Matrix")
plt.xlabel("Predicted")
plt.ylabel("Actual")
plt.show()

# Feature Importance
feat_importances = pd.Series(model.feature_importances_, index=X.columns)
feat_importances.nlargest(10).plot(kind='barh', figsize=(8,6))
plt.title("Top 10 Feature Importances")
plt.show()

# ---------------------
# 6. BUSINESS INTERPRETATION & RECOMMENDATIONS
# ---------------------
print("\n--- BUSINESS INTERPRETATION ---")
print("Key factors influencing clicks (top features):")
print(feat_importances.nlargest(5))

print("""
Recommendations:
1. Focus ad spend on demographics with higher predicted click-through (e.g., Age/Income groups).
2. Schedule ads during Hours with high predicted click probability.
3. Optimize Ad_Topic combinations that yield strong engagement.
4. Reduce spend on low-engagement segments to minimize wasted budget.
""")

# ---------------------
# 7. SAVING THE MODEL FOR DEPLOYMENT
# ---------------------
with open("ad_click_model.pkl", "wb") as f:
    pickle.dump({"model": model, "features": X.columns.tolist()}, f)

print("\nModel saved as ad_click_model.pkl")