import joblib
import numpy as np

# Load model & scaler
model = joblib.load("../models/ctr_model.pkl")
scaler = joblib.load("../models/scaler.pkl")

# Example user input
new_user = np.array([[35, 60000, 70, 200]])
new_user_scaled = scaler.transform(new_user)

# Predict class
prediction = model.predict(new_user_scaled)[0]

# Predict probability
prob = model.predict_proba(new_user_scaled)[0][1]  # probability of "Clicked"

print(f"\n🔮 Prediction for {new_user.tolist()[0]}:")
print("Result:", "Clicked ✅" if prediction == 1 else "Not Clicked ❌")
print(f"Click Probability: {prob:.2f}")
